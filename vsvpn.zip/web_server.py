"""
web_server.py - Production-Ready VPN Server with Flask + Waitress
Version: 2.2.1 - Added Waitress Production WSGI Server, Force Admin Logout Features.
Features: Admin Dashboard, VPN Client API, Session Management, Security Logging, License Management
"""

from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_socketio import SocketIO, emit
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from werkzeug.middleware.proxy_fix import ProxyFix
from functools import wraps
import socket
import threading
import json
import hashlib
import secrets
import pyotp
import sqlite3
from cryptography.fernet import Fernet
import os
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime, timedelta
import qrcode
import io
import base64
from PIL import Image
import time
import re
import sys

# Import modules
from license_manager import LicenseManager

# =============================================================================
# APPLICATION CONFIGURATION
# =============================================================================

class Config:
    """Application configuration"""
    SECRET_KEY = os.environ.get('SECRET_KEY') or secrets.token_hex(32)
    SESSION_COOKIE_SECURE = False  # Set to True in production with HTTPS
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    PERMANENT_SESSION_LIFETIME = timedelta(hours=8)
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max upload
    DATABASE_PATH = 'vpn_users.db'
    LOG_FILE = 'vpn_server.log'
    KEY_FILE = 'server.key'
    
    # Security settings
    RATE_LIMIT_ENABLED = True
    # **REMOVE THIS LINE - it conflicts with PERMANENT_SESSION_LIFETIME:**    
    #SESSION_TIMEOUT = 900  # 15 minutes of inactivity
    MAX_LOGIN_ATTEMPTS = 5
    LOGIN_TIMEOUT = 300  # 5 minutes lockout after max attempts
    
    # VPN settings
    HEARTBEAT_TIMEOUT = 3600  # Seconds before session is considered stale
    
    # Waitress Production Settings
    WAITRESS_HOST = '0.0.0.0'
    WAITRESS_PORT = 5000
    WAITRESS_THREADS = 8  # Number of worker threads
    WAITRESS_CHANNEL_TIMEOUT = 300  # Connection timeout
    WAITRESS_MAX_REQUEST_BODY_SIZE = 16 * 1024 * 1024  # 16MB
    USE_WAITRESS = True  # Set to False to use Flask dev server


# =============================================================================
# FLASK APPLICATION SETUP
# =============================================================================

app = Flask(__name__)
app.config.from_object(Config)

# Add ProxyFix middleware for HAProxy
app.wsgi_app = ProxyFix(
    app.wsgi_app, 
    x_for=1,      # Trust one level of X-Forwarded-For
    x_proto=1,    # Trust one level of X-Forwarded-Proto  
    x_host=1,     # Trust one level of X-Forwarded-Host
    x_port=1,     # Trust one level of X-Forwarded-Port
    x_prefix=1    # Trust one level of X-Forwarded-Prefix
)

# Initialize SocketIO
socketio = SocketIO(
    app, 
    cors_allowed_origins="*",
    async_mode='threading',
    logger=False,
    engineio_logger=False
)

# Initialize rate limiter
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"],
    storage_uri="memory://"
)

# Global locks for failed login tracking
failed_login_attempts = {}  # {ip: [(timestamp, username), ...]}
failed_login_lock = threading.Lock()


# =============================================================================
# SESSION MANAGER - FIXED VERSION
# =============================================================================

class SessionManager:
    """Thread-safe session management with isolated invalidation tracking"""
    
    def __init__(self):
        self.sessions = {}  # {session_id: session_data}
        self.user_sessions = {}  # {username: session_id}
        self.invalidated_sessions = set()  # MOVED INSIDE CLASS - FIX
        self.lock = threading.Lock()
        self.cleanup_thread = None
        self.running = False
        
    def start_cleanup_task(self):
        """Start background cleanup task"""
        self.running = True
        self.cleanup_thread = threading.Thread(target=self._cleanup_loop, daemon=True)
        self.cleanup_thread.start()
        
    def stop_cleanup_task(self):
        """Stop background cleanup task"""
        self.running = False
        if self.cleanup_thread:
            self.cleanup_thread.join(timeout=5)
            
    def _cleanup_loop(self):
        """Remove stale sessions periodically"""
        while self.running:
            try:
                time.sleep(60)  # Check every minute
                self._cleanup_stale_sessions()
            except Exception as e:
                logging.error(f"Session cleanup error: {e}")
                
    def _cleanup_stale_sessions(self):
        """Remove sessions with no heartbeat"""
        with self.lock:
            current_time = time.time()
            stale_sessions = []
            
            for session_id, session_data in self.sessions.items():
                last_heartbeat = session_data.get('last_heartbeat', 0)
                if current_time - last_heartbeat > Config.HEARTBEAT_TIMEOUT:
                    stale_sessions.append(session_id)
            
            for session_id in stale_sessions:
                username = self.sessions[session_id]['username']
                del self.sessions[session_id]
                if username in self.user_sessions and self.user_sessions[username] == session_id:
                    del self.user_sessions[username]
                self.invalidated_sessions.add(session_id)
                logging.info(f"Cleaned up stale session for user: {username}")
        
    def create_session(self, username, ip_address):
        """Create a new session for user"""
        with self.lock:
            # End existing session if user is already logged in
            if username in self.user_sessions:
                old_session_id = self.user_sessions[username]
                if old_session_id in self.sessions:
                    del self.sessions[old_session_id]
                    self.invalidated_sessions.add(old_session_id)
                    logging.info(f"Terminated old session for user: {username}")
            
            session_id = secrets.token_urlsafe(32)
            self.sessions[session_id] = {
                'username': username,
                'ip': ip_address,
                'login_time': time.time(),
                'last_heartbeat': time.time(),
                'last_activity': time.time()
            }
            self.user_sessions[username] = session_id
            return session_id
    
    def validate_session(self, username, session_id):
        """Validate if session is valid for user"""
        with self.lock:
            if session_id not in self.sessions:
                return False
            session_data = self.sessions[session_id]
            if session_data['username'] != username:
                return False
            if self.user_sessions.get(username) != session_id:
                return False
            if session_id in self.invalidated_sessions:
                return False
            return True
    
    def update_heartbeat(self, session_id):
        """Update session heartbeat timestamp"""
        with self.lock:
            if session_id in self.sessions:
                self.sessions[session_id]['last_heartbeat'] = time.time()
                self.sessions[session_id]['last_activity'] = time.time()
                return True
            return False
    
    def update_activity(self, session_id):
        """Update last activity timestamp"""
        with self.lock:
            if session_id in self.sessions:
                self.sessions[session_id]['last_activity'] = time.time()
                return True
            return False
    
    def end_session(self, session_id):
        """End a session"""
        with self.lock:
            if session_id in self.sessions:
                username = self.sessions[session_id]['username']
                del self.sessions[session_id]
                if username in self.user_sessions and self.user_sessions[username] == session_id:
                    del self.user_sessions[username]
                self.invalidated_sessions.add(session_id)
                logging.info(f"Ended session for user: {username}")
                return True
            return False
    
    def is_active(self, session_id):
        """Check if session is active"""
        with self.lock:
            return (session_id in self.sessions and 
                    session_id not in self.invalidated_sessions)
    
    def is_user_logged_in(self, username):
        """Check if user has active session"""
        with self.lock:
            return username in self.user_sessions
    
    def get_active_sessions_count(self):
        """Get count of active sessions"""
        with self.lock:
            return len(self.sessions)
    
    def get_active_sessions(self):
        """Get list of active sessions"""
        with self.lock:
            return [dict(data) for data in self.sessions.values()]
    
    def get_session_by_id(self, session_id):
        """Get session data by ID"""
        with self.lock:
            return self.sessions.get(session_id)


# =============================================================================
# VPN SERVER CLASS
# =============================================================================

class VPNServer:
    """Main VPN server with database and authentication"""
    
    def __init__(self, host='0.0.0.0', port=8888):
        self.host = host
        self.port = port
        self.clients = {}
        self.setup_logging()
        self.encryption_key = self.load_or_generate_key()
        self.cipher = Fernet(self.encryption_key)
        self.setup_database()
        self.admin_totp_secret = None  # Store admin TOTP secret
        self.license_manager = LicenseManager(self.conn)
        self.session_manager = SessionManager()
        self.session_manager.start_cleanup_task()
        
        # Start license check task
        self.start_license_check_task()

    def start_license_check_task(self):
        """Start background license check task"""
        self.license_check_running = True
        self.license_check_thread = threading.Thread(target=self._license_check_loop, daemon=True)
        self.license_check_thread.start()
    
    def stop_license_check_task(self):
        """Stop background license check task"""
        self.license_check_running = False
        if hasattr(self, 'license_check_thread'):
            self.license_check_thread.join(timeout=5)

    def _license_check_loop(self):
        """Check license status periodically"""
        while self.license_check_running:
            try:
                time.sleep(3600)  # Check every hour
                license_info = self.license_manager.get_license_info()
            
                if license_info:
                    # If expired, disable users
                    if license_info['status'] == 'EXPIRED' or license_info['days_remaining'] <= 0:
                        disabled_count = self.license_manager.disable_users_on_license_expiry()
                        if disabled_count > 0:
                            self.logger.warning(f"⚠️ License expired! Disabled {disabled_count} non-admin users")
                        
            except Exception as e:
                self.logger.error(f"License check error: {e}")
        
    def load_or_generate_key(self):
        """Load or generate encryption key"""
        key_file = Config.KEY_FILE
        if os.path.exists(key_file):
            with open(key_file, 'rb') as f:
                return f.read()
        else:
            key = Fernet.generate_key()
            with open(key_file, 'wb') as f:
                f.write(key)
            logging.info(f"Generated new encryption key: {key_file}")
            return key
        
    def setup_logging(self):
        """Setup logging with rotation"""
        log_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        # File handler with rotation
        file_handler = RotatingFileHandler(
            Config.LOG_FILE,
            maxBytes=10*1024*1024,  # 10MB
            backupCount=5
        )
        file_handler.setFormatter(log_formatter)
        file_handler.setLevel(logging.INFO)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(log_formatter)
        console_handler.setLevel(logging.INFO)
        
        # Root logger
        logging.basicConfig(
            level=logging.INFO,
            handlers=[file_handler, console_handler]
        )
        
        self.logger = logging.getLogger(__name__)
        self.logger.info("=" * 60)
        self.logger.info("VPN Server Started")
        self.logger.info("=" * 60)
        
    def setup_database(self):
        """Setup SQLite database with tables"""
        self.conn = sqlite3.connect(
            Config.DATABASE_PATH, 
            check_same_thread=False,
            timeout=10.0
        )
        self.conn.row_factory = sqlite3.Row
        cursor = self.conn.cursor()
        
        # Users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                salt TEXT NOT NULL,
                twofa_secret TEXT,
                twofa_enabled INTEGER DEFAULT 1,
                role TEXT DEFAULT 'user',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_login DATETIME,
                status TEXT DEFAULT 'ACTIVE',
                is_active INTEGER DEFAULT 1,
                email TEXT,
                notes TEXT
            )
        ''')
        
        # Login logs table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS login_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                username TEXT NOT NULL,
                login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
                ip_address TEXT NOT NULL,
                status TEXT NOT NULL,
                session_id TEXT,
                user_agent TEXT,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Create indexes for performance
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_login_logs_username 
            ON login_logs(username)
        ''')
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_login_logs_time 
            ON login_logs(login_time DESC)
        ''')
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_login_logs_status 
            ON login_logs(status)
        ''')
        
        # Migration for new columns
        self._migrate_database(cursor)
        
        # Create default admin user
        self._create_default_admin(cursor)
        
        self.conn.commit()
        self.logger.info("Database initialized successfully")
        
    def _migrate_database(self, cursor):
        """Apply database migrations"""
        cursor.execute("PRAGMA table_info(users)")
        cols = [row[1] for row in cursor.fetchall()]
    
        migrations = {
            'role': "ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'user'",
            'twofa_enabled': "ALTER TABLE users ADD COLUMN twofa_enabled INTEGER DEFAULT 1",
            'email': "ALTER TABLE users ADD COLUMN email TEXT",
            'notes': "ALTER TABLE users ADD COLUMN notes TEXT",
            'is_active': "ALTER TABLE users ADD COLUMN is_active INTEGER DEFAULT 1"  # NEW
        }
    
        for col, sql in migrations.items():
            if col not in cols:
                try:
                    cursor.execute(sql)
                    self.logger.info(f"Applied migration: Added {col} column")
                except Exception as e:
                    self.logger.error(f"Migration error for {col}: {e}")
    
        # Ensure admin has admin role
        try:
            cursor.execute("UPDATE users SET role = 'admin' WHERE username='admin'")
        except Exception as e:
            self.logger.error(f"Error updating admin role: {e}")

            
    def _create_default_admin(self, cursor):
        """Create default admin account and store TOTP secret"""
        cursor.execute("SELECT COUNT(*) FROM users WHERE username='admin'")
        if cursor.fetchone()[0] == 0:
            salt, password_hash = self.hash_password('admin123')
            twofa_secret = self.generate_2fa_secret()
            self.admin_totp_secret = twofa_secret  # Store TOTP secret
            cursor.execute('''
                INSERT INTO users (username, password_hash, salt, twofa_secret, twofa_enabled, role)
                VALUES (?, ?, ?, ?, 1, 'admin')
            ''', ('admin', password_hash, salt, twofa_secret))
            self.logger.warning(f"⚠️  Default admin created: admin/admin123")
            self.logger.warning(f"⚠️  Admin 2FA Secret: {twofa_secret}")
            self.logger.warning(f"⚠️  CHANGE DEFAULT PASSWORD IMMEDIATELY!")
        else:
            cursor.execute("UPDATE users SET role = 'admin' WHERE username='admin'")
            cursor.execute("SELECT twofa_secret FROM users WHERE username='admin'")
            result = cursor.fetchone()
            if result and result[0]:
                self.admin_totp_secret = result[0]  # Store existing TOTP secret
    
    def get_admin_2fa_secret(self):
        """Get admin 2FA secret from database"""
        try:
            cursor = self.conn.cursor()
            cursor.execute("SELECT twofa_secret FROM users WHERE username='admin'")
            result = cursor.fetchone()
            if result and result[0]:
                return result[0]
            return None
        except Exception as e:
            self.logger.error(f"Error getting admin 2FA secret: {e}")
            return None
        
    def hash_password(self, password, salt=None):
        """Hash password with salt"""
        if salt is None:
            salt = secrets.token_hex(16)
        password_hash = hashlib.pbkdf2_hmac(
            'sha256', 
            password.encode('utf-8'), 
            salt.encode('utf-8'), 
            100000
        )
        return salt, password_hash.hex()
        
    def verify_password(self, password, salt, stored_hash):
        """Verify password against hash"""
        _, computed_hash = self.hash_password(password, salt)
        return secrets.compare_digest(computed_hash, stored_hash)
        
    def generate_2fa_secret(self):
        """Generate 2FA secret"""
        return pyotp.random_base32()
        
    def verify_2fa(self, secret, token):
        """Verify 2FA token"""
        if not secret or not token:
            return False
        try:
            totp = pyotp.TOTP(secret)
            return totp.verify(token, valid_window=1)
        except Exception as e:
            self.logger.error(f"2FA verification error: {e}")
            return False
        
    def log_login_attempt(self, username, ip_address, status, user_id=None, session_id=None, user_agent=None):
        """Log login attempt to database"""
        try:
            cursor = self.conn.cursor()
            cursor.execute('''
                INSERT INTO login_logs (user_id, username, ip_address, status, session_id, user_agent)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (user_id, username, ip_address, status, session_id, user_agent))
            self.conn.commit()
        except Exception as e:
            self.logger.error(f"Error logging login attempt: {e}")
        
    def log_logout(self, username, ip_address, user_id=None, session_id=None):
        """Log logout event"""
        self.log_login_attempt(username, ip_address, "LOGOUT", user_id, session_id)
        
    def log_2fa_change(self, username, user_id, enabled, changed_by='system'):
        """Log 2FA status change"""
        status = "2FA_ENABLED" if enabled else "2FA_DISABLED"
        self.log_login_attempt(username, f"SYSTEM:{changed_by}", status, user_id)
        
    def log_password_change(self, username, user_id, changed_by, ip_address):
        """Log password change"""
        status = f"PASSWORD_CHANGED_BY:{changed_by}"
        self.log_login_attempt(username, ip_address, status, user_id)
        
    def register_user(self, username, password, enable_2fa=True, role='user', email=None):
        """Register new user"""
        # Validate username
        if not re.match(r'^[a-zA-Z0-9_]{3,20}$', username):
            return False, "Username must be 3-20 characters (letters, numbers, underscore)"
        
        # Validate password
        if len(password) < 6:
            return False, "Password must be at least 6 characters"
        
        # Validate role
        if role not in ['admin', 'user']:
            role = 'user'
            
        cursor = self.conn.cursor()
        try:
            salt, password_hash = self.hash_password(password)
            twofa_secret = self.generate_2fa_secret() if enable_2fa else None
            
            cursor.execute('''
                INSERT INTO users (username, password_hash, salt, twofa_secret, twofa_enabled, role, email)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (username, password_hash, salt, twofa_secret, 1 if enable_2fa else 0, role, email))
            
            self.conn.commit()
            self.log_login_attempt(
                username, 
                'SYSTEM:register', 
                f'USER_CREATED_ROLE_{role.upper()}_2FA_{"ENABLED" if enable_2fa else "DISABLED"}'
            )
            return True, twofa_secret
        except sqlite3.IntegrityError:
            return False, "Username already exists"
        except Exception as e:
            self.logger.error(f"User registration error: {e}")
            return False, str(e)
            
    def change_password(self, user_id, old_password, new_password, changed_by_admin=False, admin_username=None):
        """Change user password"""
        cursor = self.conn.cursor()
        
        try:
            cursor.execute('''
                SELECT username, password_hash, salt, status 
                FROM users WHERE id=?
            ''', (user_id,))
            
            result = cursor.fetchone()
            if not result:
                return False, "User not found"
            
            username, stored_hash, salt, status = result
            
            if status != 'ACTIVE':
                return False, "Account is inactive"
            
            # Verify old password (skip if admin is changing)
            if not changed_by_admin:
                if not self.verify_password(old_password, salt, stored_hash):
                    return False, "Current password is incorrect"
            
            # Validate new password
            if len(new_password) < 6:
                return False, "New password must be at least 6 characters"
            
            if not changed_by_admin and new_password == old_password:
                return False, "New password must be different from current password"
            
            # Hash new password
            new_salt, new_hash = self.hash_password(new_password)
            
            # Update password
            cursor.execute('''
                UPDATE users 
                SET password_hash = ?, salt = ? 
                WHERE id = ?
            ''', (new_hash, new_salt, user_id))
            
            self.conn.commit()
            
            # Log the change
            changed_by = admin_username if changed_by_admin else username
            self.log_password_change(username, user_id, changed_by, 'WEB_INTERFACE')
            
            return True, "Password changed successfully"
            
        except Exception as e:
            self.logger.error(f"Password change error: {e}")
            return False, str(e)
            
    def authenticate_user(self, username, password, twofa_token, ip_address, is_web_login=False, user_agent=None):
        """Authenticate user with credentials and license check"""
        cursor = self.conn.cursor()
    
        # Check for concurrent session
        if not is_web_login and self.session_manager.is_user_logged_in(username):
            self.log_login_attempt(username, ip_address, "FAILED_CONCURRENT_SESSION", user_agent=user_agent)
            return False, "User already logged in", None, None
    
        # Get user from database
        cursor.execute('''
            SELECT id, password_hash, salt, twofa_secret, twofa_enabled, status, role, is_active 
            FROM users WHERE username=?
        ''', (username,))
    
        result = cursor.fetchone()
        if not result:
            self.log_login_attempt(username, ip_address, "FAILED_USER_NOT_FOUND",  user_agent=user_agent)
            return False, "Invalid credentials", None, None
    
        user_id, stored_hash, salt, twofa_secret, twofa_enabled, status, role, is_active = result

        # Restrict web dashboard to admin only
        if is_web_login and role != 'admin':
            self.log_login_attempt(username, ip_address, "FAILED_INSUFFICIENT_PRIVILEGES", user_id, user_agent=user_agent)
            return False, "Access denied: Admin privileges required", None, None
    
        # Check if user is active (for non-admin users)
        if not is_active and role != 'admin':
            self.log_login_attempt(username, ip_address, "FAILED_ACCOUNT_DISABLED", user_id, user_agent=user_agent)
            return False, "⚠️ ACCOUNT DISABLED\n\nYour account has been disabled. This may be due to license expiry.\nPlease contact your administrator.", None, None
       
        # Check account status
        if status != 'ACTIVE':
            self.log_login_attempt(username, ip_address, "FAILED_INACTIVE", user_id, user_agent=user_agent)
            return False, "Account inactive", None, None
    
        # Check license status for non-admin users (VPN login only)
        if not is_web_login and role != 'admin':
            login_allowed, license_message = self.license_manager.check_user_login_allowed(username, role)
            if not login_allowed:
                self.log_login_attempt(username, ip_address, "FAILED_LICENSE_EXPIRED", user_id, user_agent=user_agent)
                return False, license_message, None, None
        
        # Verify password
        if not self.verify_password(password, salt, stored_hash):
            self.log_login_attempt(username, ip_address, "FAILED_PASSWORD", user_id, user_agent=user_agent)
            return False, "Invalid credentials", None, None
        
        # Verify 2FA if enabled
        if twofa_enabled:
            if not twofa_token:
                self.log_login_attempt(username, ip_address, "FAILED_2FA_MISSING", user_id, user_agent=user_agent)
                return False, "2FA token required", None, None
            if not self.verify_2fa(twofa_secret, twofa_token):
                self.log_login_attempt(username, ip_address, "FAILED_2FA", user_id, user_agent=user_agent)
                return False, "Invalid 2FA token", None, None
    
        # Create session
        session_id = self.session_manager.create_session(username, ip_address)
    
        # Update last login
        cursor.execute(
            'UPDATE users SET last_login = ? WHERE id = ?', 
            (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), user_id)
        )
        self.conn.commit()
    
        self.log_login_attempt(username, ip_address, "SUCCESS", user_id, session_id, user_agent)
        self.logger.info(f"✓ User authenticated: {username} from {ip_address}")
        return True, "Authentication successful", user_id, session_id


# =============================================================================
# INITIALIZE SERVER
# =============================================================================

vpn_server = VPNServer()


# =============================================================================
# DECORATORS - FIXED VERSION
# =============================================================================

# **ADD THIS HERE - Before the login_required decorator**
@app.before_request
def refresh_session():
    """Keep session alive on every request"""
    if 'username' in session:
        session.modified = True
        session.permanent = True

def login_required(f):
    """Decorator to require login - FIXED to use session_manager"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        session_id = session.get('session_id')
        username = session.get('username')
        
        if not session_id or not username:
            session.clear()
            if request.path.startswith('/api/'):
                return jsonify({'status': 'error', 'message': 'Authentication required'}), 401
            return redirect(url_for('login'))
        
        # Check if session is invalidated - FIXED
        if session_id in vpn_server.session_manager.invalidated_sessions:
            session.clear()
            if request.path.startswith('/api/'):
                return jsonify({'status': 'error', 'message': 'Session terminated'}), 401
            return redirect(url_for('login'))
        
        # Check if session is still active
        if not vpn_server.session_manager.is_active(session_id):
            session.clear()
            if request.path.startswith('/api/'):
                return jsonify({'status': 'error', 'message': 'Session expired'}), 401
            return redirect(url_for('login'))
        
        # Update activity
        vpn_server.session_manager.update_activity(session_id)
 
        # **FIX: Refresh Flask session to prevent timeout**
        session.modified = True
 
        return f(*args, **kwargs)
    return decorated_function


def check_failed_logins(ip_address):
    """Check and limit failed login attempts"""
    if not Config.RATE_LIMIT_ENABLED:
        return True
        
    with failed_login_lock:
        current_time = time.time()
        
        # Clean old attempts
        if ip_address in failed_login_attempts:
            failed_login_attempts[ip_address] = [
                (t, u) for t, u in failed_login_attempts[ip_address]
                if current_time - t < Config.LOGIN_TIMEOUT
            ]
        
        # Check if locked out
        if ip_address in failed_login_attempts:
            if len(failed_login_attempts[ip_address]) >= Config.MAX_LOGIN_ATTEMPTS:
                return False
        
        return True


def record_failed_login(ip_address, username):
    """Record a failed login attempt"""
    if not Config.RATE_LIMIT_ENABLED:
        return
        
    with failed_login_lock:
        if ip_address not in failed_login_attempts:
            failed_login_attempts[ip_address] = []
        failed_login_attempts[ip_address].append((time.time(), username))


def clear_failed_logins(ip_address):
    """Clear failed login attempts for IP"""
    with failed_login_lock:
        if ip_address in failed_login_attempts:
            del failed_login_attempts[ip_address]


# =============================================================================
# WEB ROUTES
# =============================================================================

@app.route('/')
def index():
    """Home page - redirect to dashboard or login"""
    if 'username' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
@limiter.limit("10 per minute")
def login():
    """Login page and handler"""
    if request.method == 'GET':
        return render_template('login.html')
    
    try:
        data = request.get_json()
        username = data.get('username', '').strip()
        password = data.get('password', '')
        twofa_token = data.get('twofa_token', '').strip()
        force_logout = data.get('force_logout', False)  # NEW: Check if force logout requested
        
        if not username or not password:
            return jsonify({'status': 'error', 'message': 'Username and password required'}), 400
        
        ip_address = request.remote_addr
        user_agent = request.headers.get('User-Agent', 'Unknown')
        
        # Check for rate limiting
        if not check_failed_logins(ip_address):
            return jsonify({
                'status': 'error', 
                'message': f'Too many failed attempts. Try again in {Config.LOGIN_TIMEOUT // 60} minutes.'
            }), 429
            
        # NEW: Check if user already logged in BEFORE authentication
        if vpn_server.session_manager.is_user_logged_in(username) and not force_logout:
            # Get existing session info
            existing_session_id = vpn_server.session_manager.user_sessions.get(username)
            existing_session_data = vpn_server.session_manager.get_session_by_id(existing_session_id)
            
            if existing_session_data:
                return jsonify({
                    'status': 'already_logged_in',
                    'message': 'User already logged in from another session',
                    'session_info': {
                        'ip': existing_session_data.get('ip', 'Unknown'),
                        'login_time': datetime.fromtimestamp(
                            existing_session_data.get('login_time', 0)
                        ).strftime('%Y-%m-%d %H:%M:%S')
                    }
                }), 409  # 409 Conflict
        
        # NEW: If force_logout is True, terminate existing session first
        if force_logout and vpn_server.session_manager.is_user_logged_in(username):
            existing_session_id = vpn_server.session_manager.user_sessions.get(username)
            if existing_session_id:
                vpn_server.session_manager.end_session(existing_session_id)
                socketio.emit('session_terminated', {
                    'username': username,
                    'session_id': existing_session_id,
                    'reason': 'force_logout_new_session'
                })
                vpn_server.logger.info(f"⚠️ Forced logout: {username} - new session from {ip_address}")
                
        # Authenticate
        success, message, user_id, session_id = vpn_server.authenticate_user(
            username, password, twofa_token, ip_address, is_web_login=True, user_agent=user_agent
        )
        
        if success:
            # Clear failed attempts
            clear_failed_logins(ip_address)
            
            # Set session - **ENSURE PERMANENT FLAG**
            session.permanent = True
            session['username'] = username
            session['user_id'] = user_id
            session['session_id'] = session_id
            session['login_time'] = time.time()
            session['last_activity'] = time.time()  # **ADD THIS**
            
            return jsonify({'status': 'success', 'message': message}), 200
        else:
            # Record failed attempt
            record_failed_login(ip_address, username)
            return jsonify({'status': 'error', 'message': message}), 401
            
    except Exception as e:
        vpn_server.logger.error(f"Login error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/logout')
@login_required
def logout():
    """Logout handler"""
    username = session.get('username')
    session_id = session.get('session_id')
    
    if session_id:
        vpn_server.session_manager.end_session(session_id)
    
    if username:
        cursor = vpn_server.conn.cursor()
        cursor.execute('SELECT id FROM users WHERE username=?', (username,))
        result = cursor.fetchone()
        user_id = result[0] if result else None
        vpn_server.log_logout(username, request.remote_addr, user_id, session_id)
        vpn_server.logger.info(f"✓ User logged out: {username}")
    
    session.clear()
    return redirect(url_for('login'))

@app.route('/api/force_logout_user', methods=['POST'])
@limiter.limit("10 per minute")
def force_logout_user():
    """Force logout a user by username (admin only)"""
    try:
        data = request.get_json()
        target_username = data.get('username', '').strip()
        requester_ip = request.remote_addr
        
        if not target_username:
            return jsonify({'status': 'error', 'message': 'Username required'}), 400
        
        # Check if target user has active session
        if not vpn_server.session_manager.is_user_logged_in(target_username):
            return jsonify({'status': 'error', 'message': 'User not logged in'}), 404
        
        # Get session ID
        session_id = vpn_server.session_manager.user_sessions.get(target_username)
        
        if not session_id:
            return jsonify({'status': 'error', 'message': 'Session not found'}), 404
        
        # Get user ID for logging
        cursor = vpn_server.conn.cursor()
        cursor.execute('SELECT id FROM users WHERE username=?', (target_username,))
        result = cursor.fetchone()
        user_id = result[0] if result else None
        
        # End session
        if vpn_server.session_manager.end_session(session_id):
            # Log forced logout
            vpn_server.log_login_attempt(
                target_username, 
                requester_ip,
                f'FORCED_LOGOUT_BY_NEW_SESSION',
                user_id, 
                session_id
            )
            
            # Emit socket event
            socketio.emit('session_terminated', {
                'username': target_username, 
                'session_id': session_id,
                'reason': 'force_logout'
            })
            
            vpn_server.logger.info(f"✓ Forced logout: {target_username} by new admin session from {requester_ip}")
            
            return jsonify({
                'status': 'success', 
                'message': f'Successfully logged out {target_username}'
            }), 200
        else:
            return jsonify({
                'status': 'error', 
                'message': 'Failed to terminate session'
            }), 500
            
    except Exception as e:
        vpn_server.logger.error(f"Force logout error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/dashboard')
@login_required
def dashboard():
    """Admin dashboard"""
    return render_template('dashboard.html', username=session.get('username'))

@app.route('/api/heartbeat', methods=['POST'])
@login_required
def web_heartbeat():
    """Web dashboard heartbeat to keep session alive"""
    session.modified = True
    # **ADD THIS: Also update SessionManager heartbeat**
    session_id = session.get('session_id')
    if session_id:
        vpn_server.session_manager.update_heartbeat(session_id)
        vpn_server.session_manager.update_activity(session_id)
        
    return jsonify({'status': 'ok'}), 200

# =============================================================================
# VPN CLIENT API ROUTES - FIXED VERSION
# =============================================================================

@app.route('/api/vpn/login', methods=['POST'])
@limiter.limit("20 per minute")
def vpn_login():
    """VPN client login endpoint (allows all roles)"""
    try:
        data = request.get_json()
        username = data.get('username', '').strip()
        password = data.get('password', '')
        twofa_token = data.get('twofa_token', '').strip()
        
        if not username or not password:
            return jsonify({'status': 'error', 'message': 'Username and password required'}), 400
        
        ip_address = request.remote_addr
        user_agent = request.headers.get('User-Agent', 'VPN Client')
        
        # Check rate limiting
        if not check_failed_logins(ip_address):
            return jsonify({
                'status': 'error',
                'message': f'Too many failed attempts. Try again in {Config.LOGIN_TIMEOUT // 60} minutes.'
            }), 429
        
        # Authenticate (allow all roles for VPN)
        success, message, user_id, session_id = vpn_server.authenticate_user(
            username, password, twofa_token, ip_address, 
            is_web_login=False, user_agent=user_agent
        )
        
        if success:
            clear_failed_logins(ip_address)
            return jsonify({
                "status": "success",
                "message": message,
                "session_id": session_id,
                "user_id": user_id
            }), 200
        else:
            record_failed_login(ip_address, username)
            return jsonify({"status": "error", "message": message}), 401
            
    except Exception as e:
        vpn_server.logger.error(f"VPN login error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/vpn/heartbeat', methods=['POST'])
@limiter.limit("200 per minute")
def vpn_heartbeat():
    """VPN client heartbeat endpoint - FIXED"""
    try:
        data = request.get_json()
        client_session_id = data.get('session_id')
        
        if not client_session_id:
            return jsonify({'status': 'error', 'message': 'No session ID provided'}), 400
        
        # Check if session is invalidated - FIXED
        if client_session_id in vpn_server.session_manager.invalidated_sessions:
            return jsonify({
                'status': 'terminated', 
                'message': 'Session terminated by administrator'
            }), 401
        
        # Check if session is active
        if not vpn_server.session_manager.is_active(client_session_id):
            return jsonify({
                'status': 'expired', 
                'message': 'Session expired'
            }), 401
        
        # Update heartbeat
        if vpn_server.session_manager.update_heartbeat(client_session_id):
            return jsonify({'status': 'active', 'message': 'Session valid'}), 200
        else:
            return jsonify({
                'status': 'error', 
                'message': 'Failed to update heartbeat'
            }), 500
            
    except Exception as e:
        vpn_server.logger.error(f"Heartbeat error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500

@app.route('/api/vpn/logout', methods=['POST'])
@limiter.limit("30 per minute")
def vpn_logout():
    """VPN client logout endpoint"""
    try:
        data = request.get_json()
        client_session_id = data.get('session_id')
        
        if not client_session_id:
            return jsonify({'status': 'error', 'message': 'No session ID provided'}), 400
        
        # Get session data before terminating
        session_data = vpn_server.session_manager.get_session_by_id(client_session_id)
        
        if not session_data:
            # Session already gone - consider it a success
            return jsonify({'status': 'success', 'message': 'Session already terminated'}), 200
        
        username = session_data['username']
        ip_address = session_data['ip']
        
        # Get user ID for logging
        cursor = vpn_server.conn.cursor()
        cursor.execute('SELECT id FROM users WHERE username=?', (username,))
        result = cursor.fetchone()
        user_id = result[0] if result else None
        
        # End session
        if vpn_server.session_manager.end_session(client_session_id):
            # Log logout
            vpn_server.log_logout(username, ip_address, user_id, client_session_id)
            vpn_server.logger.info(f"✓ VPN client logged out: {username} from {ip_address}")
            
            return jsonify({
                'status': 'success', 
                'message': 'Logged out successfully'
            }), 200
        else:
            return jsonify({
                'status': 'error', 
                'message': 'Failed to terminate session'
            }), 500
            
    except Exception as e:
        vpn_server.logger.error(f"VPN logout error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/check_2fa/<username>')
@limiter.limit("30 per minute")
def check_2fa(username):
    """Check if user requires 2FA"""
    try:
        cursor = vpn_server.conn.cursor()
        cursor.execute("""
            SELECT twofa_secret, twofa_enabled 
            FROM users 
            WHERE username = ?
        """, (username,))
        
        row = cursor.fetchone()
        
        if not row:
            # User not found - return error but don't reveal user doesn't exist
            vpn_server.logger.info(f"2FA check: User '{username}' not found")
            return jsonify({
                'status': 'error', 
                'message': 'User not found', 
                '2fa_required': False
            }), 404
        
        twofa_secret = row[0]
        twofa_enabled = row[1]
        
        # 2FA is required if BOTH secret exists AND 2FA is enabled
        requires_2fa = bool(twofa_secret) and bool(twofa_enabled)
        
        vpn_server.logger.info(
            f"2FA check for '{username}': "
            f"secret={'present' if twofa_secret else 'none'}, "
            f"enabled={bool(twofa_enabled)}, "
            f"required={requires_2fa}"
        )
        
        return jsonify({
            'status': 'success', 
            '2fa_required': requires_2fa
        }), 200
        
    except Exception as e:
        vpn_server.logger.error(f"Check 2FA error: {e}")
        return jsonify({
            'status': 'error', 
            'message': 'Internal server error',
            '2fa_required': False
        }), 500


# =============================================================================
# ADMIN API ROUTES
# =============================================================================

@app.route('/api/stats')
@login_required
def get_stats():
    """Get dashboard statistics"""
    try:
        cursor = vpn_server.conn.cursor()
        
        # Total users
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]
        
        # Active sessions
        active_sessions = vpn_server.session_manager.get_active_sessions_count()
        
        # License info
        license_info = vpn_server.license_manager.get_license_info()
        
        # Recent activity
        cursor.execute('''
            SELECT username, login_time, ip_address, status 
            FROM login_logs 
            ORDER BY login_time DESC LIMIT 20
        ''')
        recent_activity = []
        for row in cursor.fetchall():
            recent_activity.append({
                'username': row[0],
                'time': row[1],
                'ip': row[2],
                'status': row[3]
            })
        
        return jsonify({
            'total_users': total_users,
            'active_sessions': active_sessions,
            'license_info': license_info,
            'recent_activity': recent_activity
        }), 200
        
    except Exception as e:
        vpn_server.logger.error(f"Get stats error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/stats/dashboard')
@login_required
def get_dashboard_stats():
    """Get comprehensive dashboard statistics"""
    try:
        cursor = vpn_server.conn.cursor()
        
        # Users by role
        cursor.execute("SELECT role, COUNT(*) FROM users GROUP BY role")
        role_stats = dict(cursor.fetchall())
        
        # Users by status
        cursor.execute("SELECT status, COUNT(*) FROM users GROUP BY status")
        status_stats = dict(cursor.fetchall())
        
        # Today's logins
        today = datetime.now().strftime('%Y-%m-%d')
        cursor.execute("SELECT COUNT(*) FROM login_logs WHERE login_time LIKE ?", (f'{today}%',))
        today_logins = cursor.fetchone()[0]
        
        # Failed logins today
        cursor.execute("""
            SELECT COUNT(*) FROM login_logs 
            WHERE login_time LIKE ? AND status LIKE 'FAILED%'
        """, (f'{today}%',))
        failed_logins = cursor.fetchone()[0]
        
        # Top users
        cursor.execute("""
            SELECT username, COUNT(*) as login_count 
            FROM login_logs 
            WHERE status = 'SUCCESS'
            GROUP BY username 
            ORDER BY login_count DESC 
            LIMIT 5
        """)
        top_users = [{'username': row[0], 'count': row[1]} for row in cursor.fetchall()]
        
        return jsonify({
            'role_stats': role_stats,
            'status_stats': status_stats,
            'today_logins': today_logins,
            'failed_logins': failed_logins,
            'top_users': top_users
        }), 200
        
    except Exception as e:
        vpn_server.logger.error(f"Get dashboard stats error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/users')
@login_required
def get_users():
    """Get all users with active/inactive status"""
    try:
        cursor = vpn_server.conn.cursor()
        
        # Get all columns including is_active
        cursor.execute("PRAGMA table_info(users)")
        cols = [row[1] for row in cursor.fetchall()]
        
        # Build query based on available columns
        if 'is_active' in cols:
            cursor.execute('''
                SELECT id, username, created_at, last_login, status, twofa_enabled, role, email, is_active
                FROM users ORDER BY created_at DESC
            ''')
        else:
            cursor.execute('''
                SELECT id, username, created_at, last_login, status, twofa_enabled, role, email
                FROM users ORDER BY created_at DESC
            ''')
        
        users = []
        for row in cursor.fetchall():
            user_data = {
                'id': row[0],
                'username': row[1],
                'created_at': row[2],
                'last_login': row[3] or 'Never',
                'status': row[4],
                'twofa_enabled': bool(row[5]),
                'role': row[6],
                'email': row[7] or ''
            }
            
            # Add is_active status if column exists
            if 'is_active' in cols and len(row) > 8:
                user_data['is_active'] = bool(row[8])
            else:
                user_data['is_active'] = True  # Default to active if column doesn't exist
                
            users.append(user_data)
        
        return jsonify(users), 200
        
    except Exception as e:
        vpn_server.logger.error(f"Get users error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/users/create', methods=['POST'])
@login_required
def create_user():
    """Create new user"""
    try:
        data = request.get_json()
        username = data.get('username', '').strip()
        password = data.get('password', '')
        enable_2fa = data.get('enable_2fa', True)
        role = data.get('role', 'user')
        email = data.get('email', '').strip()
        
        # Validate inputs
        if not username or not password:
            return jsonify({
                'status': 'error', 
                'message': 'Username and password are required'
            }), 400
        
        # Validate role
        if role not in ['admin', 'user']:
            role = 'user'
        
        # Check license
        can_add, message = vpn_server.license_manager.can_add_user()
        if not can_add:
            return jsonify({'status': 'error', 'message': message}), 403
        
        # Create user
        success, result = vpn_server.register_user(username, password, enable_2fa, role, email)
        
        if success:
            response = {
                'status': 'success', 
                'message': f'User created successfully with role: {role}'
            }
            
            # Add QR code if 2FA enabled
            if enable_2fa and result:
                totp_uri = pyotp.totp.TOTP(result).provisioning_uri(
                    username, issuer_name="VS VPN Server"
                )
                qr = qrcode.QRCode(version=1, box_size=8, border=4)
                qr.add_data(totp_uri)
                qr.make(fit=True)
                img = qr.make_image(fill_color="black", back_color="white")
                
                buffer = io.BytesIO()
                img.save(buffer, format='PNG')
                qr_base64 = base64.b64encode(buffer.getvalue()).decode()
                
                response['qr_code'] = qr_base64
                response['secret'] = result
            
            socketio.emit('user_created', {'username': username})
            vpn_server.logger.info(f"✓ User created: {username} (role: {role})")
            return jsonify(response), 201
        else:
            return jsonify({'status': 'error', 'message': result}), 400
            
    except Exception as e:
        vpn_server.logger.error(f"Create user error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/users/<int:user_id>/delete', methods=['DELETE'])
@login_required
def delete_user(user_id):
    """Delete user"""
    try:
        cursor = vpn_server.conn.cursor()
        
        # Get username
        cursor.execute("SELECT username FROM users WHERE id = ?", (user_id,))
        result = cursor.fetchone()
        
        if not result:
            return jsonify({'status': 'error', 'message': 'User not found'}), 404
        
        username = result[0]
        current_username = session.get('username')
        
        # Prevent self-deletion
        if username == current_username:
            return jsonify({
                'status': 'error', 
                'message': 'Cannot delete your own account'
            }), 400
        
        # Prevent deleting primary admin
        if username == 'admin':
            return jsonify({
                'status': 'error', 
                'message': 'Cannot delete the primary admin account'
            }), 400
        
        # Delete user
        cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        vpn_server.conn.commit()
        
        # Log deletion
        vpn_server.log_login_attempt(
            username, 'WEB_INTERFACE',
            f'USER_DELETED_BY_{current_username}', user_id
        )
        
        # End session if logged in
        if vpn_server.session_manager.is_user_logged_in(username):
            session_id = vpn_server.session_manager.user_sessions.get(username)
            if session_id:
                vpn_server.session_manager.end_session(session_id)
        
        socketio.emit('user_deleted', {'username': username})
        vpn_server.logger.info(f"✓ User deleted: {username} by {current_username}")
        return jsonify({
            'status': 'success', 
            'message': f'User {username} deleted successfully'
        }), 200
        
    except Exception as e:
        vpn_server.logger.error(f"Delete user error: {e}")
        vpn_server.conn.rollback()
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/users/<int:user_id>/toggle_2fa', methods=['POST'])
@login_required
def toggle_2fa(user_id):
    """Toggle 2FA for user"""
    try:
        cursor = vpn_server.conn.cursor()
        cursor.execute("SELECT username, twofa_enabled FROM users WHERE id = ?", (user_id,))
        result = cursor.fetchone()
        
        if not result:
            return jsonify({'status': 'error', 'message': 'User not found'}), 404
        
        username, current = result
        
        # Admin must have 2FA
        if username == 'admin':
            return jsonify({
                'status': 'error', 
                'message': 'Admin account must have 2FA enabled'
            }), 400
        
        new_state = not bool(current)
        
        if new_state:
            # Enable 2FA
            cursor.execute("SELECT twofa_secret FROM users WHERE id = ?", (user_id,))
            secret = cursor.fetchone()[0]
            
            if not secret:
                secret = vpn_server.generate_2fa_secret()
                cursor.execute(
                    "UPDATE users SET twofa_secret = ?, twofa_enabled = 1 WHERE id = ?", 
                    (secret, user_id)
                )
            else:
                cursor.execute("UPDATE users SET twofa_enabled = 1 WHERE id = ?", (user_id,))
            
            vpn_server.conn.commit()
            vpn_server.log_2fa_change(username, user_id, True, session.get('username'))
            
            # Generate QR code
            totp_uri = pyotp.totp.TOTP(secret).provisioning_uri(
                username, issuer_name="VS VPN Server"
            )
            qr = qrcode.QRCode(version=1, box_size=8, border=4)
            qr.add_data(totp_uri)
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white")
            
            buffer = io.BytesIO()
            img.save(buffer, format='PNG')
            qr_base64 = base64.b64encode(buffer.getvalue()).decode()
            
            vpn_server.logger.info(f"✓ 2FA enabled for user: {username}")
            return jsonify({
                'status': 'success', 
                'qr_code': qr_base64, 
                'secret': secret
            }), 200
        else:
            # Disable 2FA
            cursor.execute("UPDATE users SET twofa_enabled = 0 WHERE id = ?", (user_id,))
            vpn_server.conn.commit()
            vpn_server.log_2fa_change(username, user_id, False, session.get('username'))
            vpn_server.logger.info(f"✓ 2FA disabled for user: {username}")
            return jsonify({'status': 'success', 'message': '2FA disabled'}), 200
            
    except Exception as e:
        vpn_server.logger.error(f"Toggle 2FA error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/users/<int:user_id>/change_password', methods=['POST'])
@login_required
def change_user_password(user_id):
    """Admin changes user password"""
    try:
        data = request.get_json()
        new_password = data.get('new_password', '')
        
        if not new_password:
            return jsonify({
                'status': 'error', 
                'message': 'New password is required'
            }), 400
        
        admin_username = session.get('username')
        
        success, message = vpn_server.change_password(
            user_id=user_id,
            old_password=None,
            new_password=new_password,
            changed_by_admin=True,
            admin_username=admin_username
        )
        
        if success:
            socketio.emit('password_changed', {'user_id': user_id})
            vpn_server.logger.info(f"✓ Password changed for user ID {user_id} by {admin_username}")
            return jsonify({'status': 'success', 'message': message}), 200
        else:
            return jsonify({'status': 'error', 'message': message}), 400
            
    except Exception as e:
        vpn_server.logger.error(f"Change password error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/profile/change_password', methods=['POST'])
@login_required
def change_own_password():
    """User changes own password"""
    try:
        data = request.get_json()
        old_password = data.get('old_password', '')
        new_password = data.get('new_password', '')
        
        if not old_password or not new_password:
            return jsonify({
                'status': 'error', 
                'message': 'Both old and new passwords are required'
            }), 400
        
        user_id = session.get('user_id')
        
        success, message = vpn_server.change_password(
            user_id=user_id,
            old_password=old_password,
            new_password=new_password,
            changed_by_admin=False
        )
        
        if success:
            vpn_server.logger.info(f"✓ User changed own password: {session.get('username')}")
            return jsonify({'status': 'success', 'message': message}), 200
        else:
            return jsonify({'status': 'error', 'message': message}), 400
            
    except Exception as e:
        vpn_server.logger.error(f"Change own password error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/users/<int:user_id>/update_role', methods=['POST'])
@login_required
def update_user_role(user_id):
    """Update user role"""
    try:
        data = request.get_json()
        new_role = data.get('role', 'user')
        
        if new_role not in ['admin', 'user']:
            return jsonify({
                'status': 'error', 
                'message': 'Invalid role. Must be admin or user'
            }), 400
        
        cursor = vpn_server.conn.cursor()
        cursor.execute("SELECT username, role FROM users WHERE id = ?", (user_id,))
        result = cursor.fetchone()
        
        if not result:
            return jsonify({'status': 'error', 'message': 'User not found'}), 404
        
        username, current_role = result
        
        # Prevent changing primary admin
        if username == 'admin' and new_role != 'admin':
            return jsonify({
                'status': 'error', 
                'message': 'Cannot demote primary admin account'
            }), 400
        
        if current_role == new_role:
            return jsonify({
                'status': 'error', 
                'message': f'User already has {new_role} role'
            }), 400
        
        # Update role
        cursor.execute("UPDATE users SET role = ? WHERE id = ?", (new_role, user_id))
        vpn_server.conn.commit()
        
        # Log change
        vpn_server.log_login_attempt(
            username, 'WEB_INTERFACE',
            f'ROLE_CHANGED_FROM_{current_role.upper()}_TO_{new_role.upper()}_BY_{session.get("username")}',
            user_id
        )
        
        socketio.emit('user_role_changed', {'username': username, 'new_role': new_role})
        vpn_server.logger.info(f"✓ Role changed: {username} -> {new_role}")
        return jsonify({
            'status': 'success', 
            'message': f'User role updated to {new_role}'
        }), 200
        
    except Exception as e:
        vpn_server.logger.error(f"Update role error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/users/<int:user_id>/toggle_status', methods=['POST'])
@login_required
def toggle_user_status(user_id):
    """Toggle user active/inactive status"""
    try:
        cursor = vpn_server.conn.cursor()
        cursor.execute("SELECT username, status FROM users WHERE id = ?", (user_id,))
        result = cursor.fetchone()
        
        if not result:
            return jsonify({'status': 'error', 'message': 'User not found'}), 404
        
        username, current_status = result
        current_admin = session.get('username')
        
        # Prevent deactivating admin
        if username == 'admin':
            return jsonify({
                'status': 'error', 
                'message': 'Cannot deactivate admin account'
            }), 400
        
        # Prevent deactivating self
        if username == current_admin:
            return jsonify({
                'status': 'error', 
                'message': 'Cannot deactivate your own account'
            }), 400
        
        new_status = 'INACTIVE' if current_status == 'ACTIVE' else 'ACTIVE'
        
        # Update status
        cursor.execute("UPDATE users SET status = ? WHERE id = ?", (new_status, user_id))
        vpn_server.conn.commit()
        
        # End session if deactivating
        if new_status == 'INACTIVE' and vpn_server.session_manager.is_user_logged_in(username):
            session_id = vpn_server.session_manager.user_sessions.get(username)
            if session_id:
                vpn_server.session_manager.end_session(session_id)
                socketio.emit('session_terminated', {'username': username, 'session_id': session_id})
        
        # Log change
        vpn_server.log_login_attempt(
            username, 'WEB_INTERFACE',
            f'STATUS_CHANGED_TO_{new_status}_BY_{current_admin}',
            user_id
        )
        
        socketio.emit('user_status_changed', {'username': username, 'status': new_status})
        vpn_server.logger.info(f"✓ Status changed: {username} -> {new_status}")
        return jsonify({
            'status': 'success', 
            'message': f'User {new_status.lower()}'
        }), 200
        
    except Exception as e:
        vpn_server.logger.error(f"Toggle status error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/sessions')
@login_required
def get_sessions():
    """Get active sessions"""
    try:
        sessions = vpn_server.session_manager.get_active_sessions()
        result = []
        
        # Get session IDs
        session_ids = {}
        with vpn_server.session_manager.lock:
            for session_id, session_data in vpn_server.session_manager.sessions.items():
                username = session_data['username']
                session_ids[username] = session_id
        
        for s in sessions:
            username = s['username']
            session_id = session_ids.get(username, '')
            
            result.append({
                'username': username,
                'ip': s['ip'],
                'login_time': datetime.fromtimestamp(s['login_time']).strftime('%Y-%m-%d %H:%M:%S'),
                'duration': int(time.time() - s['login_time']),
                'session_id': session_id
            })
        
        return jsonify(result), 200
        
    except Exception as e:
        vpn_server.logger.error(f"Get sessions error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/sessions/<session_id>/terminate', methods=['POST'])
@login_required
def terminate_session(session_id):
    """Terminate user session"""
    try:
        # Get session data
        session_data = vpn_server.session_manager.get_session_by_id(session_id)
        
        if not session_data:
            return jsonify({'status': 'error', 'message': 'Session not found'}), 404
        
        username = session_data['username']
        current_username = session.get('username')
        
        # Prevent terminating own session
        if username == current_username:
            return jsonify({
                'status': 'error', 
                'message': 'Cannot terminate your own session'
            }), 400
        
        # Terminate session
        if vpn_server.session_manager.end_session(session_id):
            vpn_server.log_login_attempt(
                username, session_data['ip'],
                f'SESSION_TERMINATED_BY_{current_username}',
                None, session_id
            )
            
            socketio.emit('session_terminated', {
                'username': username, 
                'session_id': session_id
            })
            
            vpn_server.logger.info(f"✓ Session terminated: {username} by {current_username}")
            return jsonify({
                'status': 'success', 
                'message': f'Session for {username} terminated'
            }), 200
        else:
            return jsonify({
                'status': 'error', 
                'message': 'Failed to terminate session'
            }), 500
            
    except Exception as e:
        vpn_server.logger.error(f"Terminate session error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/logs/security')
@login_required
def get_security_logs():
    """Get security logs"""
    try:
        cursor = vpn_server.conn.cursor()
        cursor.execute('''
            SELECT id, username, login_time, ip_address, status
            FROM login_logs 
            ORDER BY login_time DESC 
            LIMIT 500
        ''')
        
        logs = []
        for row in cursor.fetchall():
            logs.append({
                'id': row[0],
                'username': row[1],
                'time': row[2],
                'ip': row[3],
                'status': row[4]
            })
        
        return jsonify(logs), 200
        
    except Exception as e:
        vpn_server.logger.error(f"Get security logs error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/logs/export', methods=['POST'])
@login_required
def export_logs():
    """Export logs to JSON"""
    try:
        data = request.get_json()
        limit = min(data.get('limit', 1000), 10000)  # Max 10000
        
        cursor = vpn_server.conn.cursor()
        cursor.execute('''
            SELECT id, username, login_time, ip_address, status, session_id
            FROM login_logs 
            ORDER BY login_time DESC 
            LIMIT ?
        ''', (limit,))
        
        logs = []
        for row in cursor.fetchall():
            logs.append({
                'id': row[0],
                'username': row[1],
                'timestamp': row[2],
                'ip_address': row[3],
                'status': row[4],
                'session_id': row[5]
            })
        
        return jsonify({
            'status': 'success',
            'count': len(logs),
            'logs': logs,
            'exported_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }), 200
        
    except Exception as e:
        vpn_server.logger.error(f"Export logs error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/license/info')
@login_required
def get_license_info():
    """Get license information"""
    try:
        info = vpn_server.license_manager.get_license_info()
        return jsonify(info), 200
    except Exception as e:
        vpn_server.logger.error(f"Get license info error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/license/activate', methods=['POST'])
@login_required
def activate_license():
    """Activate license"""
    try:
        data = request.get_json()
        license_key = data.get('license_key', '').strip().upper()
        
        if not license_key:
            return jsonify({'status': 'error', 'message': 'License key required'}), 400
        
        success, message = vpn_server.license_manager.activate_license(license_key)
        
        if success:
            socketio.emit('license_activated')
            vpn_server.logger.info(f"✓ License activated by {session.get('username')}")
            return jsonify({'status': 'success', 'message': message}), 200
        else:
            return jsonify({'status': 'error', 'message': message}), 400
            
    except Exception as e:
        vpn_server.logger.error(f"Activate license error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/license/hardware')
@login_required
def get_hardware_info():
    """Get hardware information"""
    try:
        hardware_id, device_name = vpn_server.license_manager.get_hardware_id()
        return jsonify({
            'hardware_id': hardware_id,
            'device_name': device_name
        }), 200
    except Exception as e:
        vpn_server.logger.error(f"Get hardware info error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/license/check_status')
@login_required
def check_license_status():
    """Check and update license status"""
    try:
        # This will automatically disable users if license is expired
        license_info = vpn_server.license_manager.get_license_info()
        
        if license_info:
            # Check if expired and needs to disable users
            if license_info['status'] == 'EXPIRED' or license_info['days_remaining'] <= 0:
                disabled_count = vpn_server.license_manager.disable_users_on_license_expiry()
                return jsonify({
                    'status': 'expired',
                    'license_info': license_info,
                    'users_disabled': disabled_count,
                    'message': 'License expired. Non-admin users have been disabled.'
                }), 200
            else:
                return jsonify({
                    'status': 'active',
                    'license_info': license_info,
                    'message': 'License is active'
                }), 200
        else:
            return jsonify({
                'status': 'no_license',
                'message': 'No license found'
            }), 200
            
    except Exception as e:
        vpn_server.logger.error(f"Check license status error: {e}")
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500


@app.route('/api/system/info')
@login_required
def get_system_info():
    """Get system information"""
    import platform
    
    try:
        import psutil
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        return jsonify({
            'status': 'success',
            'system': {
                'platform': platform.system(),
                'platform_version': platform.version(),
                'architecture': platform.machine(),
                'hostname': platform.node(),
                'python_version': platform.python_version()
            },
            'resources': {
                'cpu_percent': cpu_percent,
                'memory_total_gb': round(memory.total / (1024**3), 2),
                'memory_used_gb': round(memory.used / (1024**3), 2),
                'memory_percent': memory.percent,
                'disk_total_gb': round(disk.total / (1024**3), 2),
                'disk_used_gb': round(disk.used / (1024**3), 2),
                'disk_percent': disk.percent
            }
        }), 200
    except ImportError:
        return jsonify({
            'status': 'partial',
            'system': {
                'platform': platform.system(),
                'platform_version': platform.version(),
                'architecture': platform.machine(),
                'hostname': platform.node(),
                'python_version': platform.python_version()
            },
            'message': 'Install psutil for resource monitoring: pip install psutil'
        }), 200
    except Exception as e:
        vpn_server.logger.error(f"Get system info error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


# =============================================================================
# WEBSOCKET EVENTS - FIXED VERSION
# =============================================================================

@socketio.on('connect')
def handle_connect():
    """Handle WebSocket connection"""
    if 'username' not in session:
        return False
    vpn_server.logger.info(f"WebSocket connected: {session.get('username')}")
    return True


@socketio.on('disconnect')
def handle_disconnect():
    """Handle WebSocket disconnection"""
    if 'username' in session:
        vpn_server.logger.info(f"WebSocket disconnected: {session.get('username')}")


@socketio.on('heartbeat')
def handle_heartbeat():
    """Handle web dashboard heartbeat - FIXED"""
    if 'session_id' not in session:
        emit('session_terminated', {'message': 'No session'})
        return
    
    session_id = session['session_id']
    
    # Check if invalidated - FIXED
    if session_id in vpn_server.session_manager.invalidated_sessions:
        emit('session_terminated', {'message': 'Session terminated by administrator'})
        return
    
    # Update heartbeat
    if vpn_server.session_manager.update_heartbeat(session_id):
        emit('heartbeat_ack', {'status': 'ok'})
    else:
        emit('session_terminated', {'message': 'Session expired'})


# =============================================================================
# ERROR HANDLERS
# =============================================================================

@app.errorhandler(404)
def not_found(e):
    """Handle 404 errors"""
    if request.path.startswith('/api/'):
        return jsonify({'status': 'error', 'message': 'Endpoint not found'}), 404
    return redirect(url_for('login'))


@app.errorhandler(500)
def internal_error(e):
    """Handle 500 errors"""
    vpn_server.logger.error(f"Internal error: {str(e)}")
    if request.path.startswith('/api/'):
        return jsonify({'status': 'error', 'message': 'Internal server error'}), 500
    return "Internal Server Error", 500


@app.errorhandler(403)
def forbidden(e):
    """Handle 403 errors"""
    if request.path.startswith('/api/'):
        return jsonify({'status': 'error', 'message': 'Forbidden'}), 403
    return redirect(url_for('login'))


@app.errorhandler(429)
def ratelimit_handler(e):
    """Handle rate limit errors"""
    if request.path.startswith('/api/'):
        return jsonify({'status': 'error', 'message': 'Rate limit exceeded'}), 429
    return "Rate limit exceeded. Please try again later.", 429


# =============================================================================
# SHUTDOWN HANDLER
# =============================================================================

def cleanup():
    """Cleanup before shutdown"""
    try:
        vpn_server.logger.info("Shutting down server...")
        
        # Stop session cleanup task
        vpn_server.session_manager.stop_cleanup_task()
        
        # Stop license check task
        if hasattr(vpn_server, 'stop_license_check_task'):
            vpn_server.stop_license_check_task()
        
        # Close database connection
        if hasattr(vpn_server, 'conn'):
            vpn_server.conn.close()
        
        vpn_server.logger.info("Server shutdown complete")
    except Exception as e:
        vpn_server.logger.error(f"Cleanup error: {e}")


import atexit
atexit.register(cleanup)


# =============================================================================
# PRODUCTION SERVER WITH WAITRESS
# =============================================================================

def run_production_server():
    """Run server with Waitress (production WSGI server)"""
    try:
        from waitress import serve
        
        print("\n" + "=" * 70)
        print("🔒 VS VPN SERVER - PRODUCTION MODE (Waitress)")
        print("=" * 70)
        print(f"🌐 Server URL:        http://{Config.WAITRESS_HOST}:{Config.WAITRESS_PORT}")
        print(f"👤 Default Admin:     admin / admin123")
        
        if vpn_server.admin_totp_secret:
            print(f"🔐 Admin 2FA Secret:  {vpn_server.admin_totp_secret}")
            print(f"📱 2FA Setup:         Scan QR in Google Authenticator/Authy")
        
        print(f"⚙️  Worker Threads:    {Config.WAITRESS_THREADS}")
        print(f"⏱️  Channel Timeout:   {Config.WAITRESS_CHANNEL_TIMEOUT}s")
        print(f"📊 Max Request Size:  {Config.WAITRESS_MAX_REQUEST_BODY_SIZE // (1024*1024)}MB")
        print(f"🔍 Rate Limiting:     {'Enabled' if Config.RATE_LIMIT_ENABLED else 'Disabled'}")
        print("=" * 70)
        print("\n⚠️  IMPORTANT SECURITY NOTES:")
        print("   1. Change default admin password immediately!")
        print("   2. Save 2FA secret in secure location")
        print("   3. Enable HTTPS with reverse proxy (nginx/Apache)")
        print("   4. Set SESSION_COOKIE_SECURE=True with HTTPS")
        print("   5. Configure firewall to restrict access")
        print("\n🚀 Server starting...\n")
        
        # Serve with Waitress
        serve(
            app,
            host=Config.WAITRESS_HOST,
            port=Config.WAITRESS_PORT,
            threads=Config.WAITRESS_THREADS,
            channel_timeout=Config.WAITRESS_CHANNEL_TIMEOUT,
            max_request_body_size=Config.WAITRESS_MAX_REQUEST_BODY_SIZE,
            url_scheme='http',  # Change to 'https' if using SSL
            ident='VPN-Server/2.1'  # Server identification
        )
        
    except ImportError:
        print("\n" + "=" * 70)
        print("❌ ERROR: Waitress not installed")
        print("=" * 70)
        print("\nTo install Waitress, run:")
        print("  pip install waitress")
        print("\nOr to install all requirements:")
        print("  pip install -r requirements.txt")
        print("=" * 70)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n\n🛑 Server stopped by user")
        cleanup()
    except Exception as e:
        print(f"\n\n❌ Server error: {e}")
        vpn_server.logger.error(f"Server error: {e}")
        cleanup()
        sys.exit(1)


def run_development_server():
    """Run server with Flask development server (NOT for production)"""
    print("\n" + "=" * 70)
    print("⚠️  VS VPN SERVER - DEVELOPMENT MODE")
    print("=" * 70)
    print("⚠️  WARNING: Using Flask development server")
    print("⚠️  NOT suitable for production use!")
    print("⚠️  Set USE_WAITRESS=True for production")
    print("=" * 70)
    print(f"🌐 Server URL:        http://0.0.0.0:5000")
    print(f"👤 Default Admin:     admin / admin123")
    
    if vpn_server.admin_totp_secret:
        print(f"🔐 Admin 2FA Secret:  {vpn_server.admin_totp_secret}")
    
    print("=" * 70 + "\n")
    
    try:
        socketio.run(
            app,
            host='0.0.0.0',
            port=5000,
            debug=False,
            use_reloader=False,
            log_output=True
        )
    except KeyboardInterrupt:
        print("\n\n🛑 Server stopped by user")
        cleanup()
    except Exception as e:
        print(f"\n\n❌ Server error: {e}")
        vpn_server.logger.error(f"Server error: {e}")
        cleanup()


# =============================================================================
# MAIN ENTRY POINT
# =============================================================================

if __name__ == '__main__':
    # Ensure admin 2FA secret is loaded
    if not vpn_server.admin_totp_secret:
        vpn_server.admin_totp_secret = vpn_server.get_admin_2fa_secret()
    
    # Choose server mode
    if Config.USE_WAITRESS:
        run_production_server()
    else:
        run_development_server()